// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crypto_dao.dart';

// ignore_for_file: type=lint
mixin _$CryptoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CryptosTable get cryptos => attachedDatabase.cryptos;
}
