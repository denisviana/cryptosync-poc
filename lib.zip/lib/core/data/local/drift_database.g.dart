// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'drift_database.dart';

// ignore_for_file: type=lint
class $CryptosTable extends Cryptos with TableInfo<$CryptosTable, Crypto> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CryptosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _symbolMeta = const VerificationMeta('symbol');
  @override
  late final GeneratedColumn<String> symbol = GeneratedColumn<String>(
      'symbol', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _priceMeta = const VerificationMeta('price');
  @override
  late final GeneratedColumn<double> price = GeneratedColumn<double>(
      'price', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _changePercentMeta =
      const VerificationMeta('changePercent');
  @override
  late final GeneratedColumn<double> changePercent = GeneratedColumn<double>(
      'change_percent', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _lastUpdatedMeta =
      const VerificationMeta('lastUpdated');
  @override
  late final GeneratedColumn<int> lastUpdated = GeneratedColumn<int>(
      'last_updated', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns =>
      [symbol, name, price, changePercent, lastUpdated];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cryptos';
  @override
  VerificationContext validateIntegrity(Insertable<Crypto> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('symbol')) {
      context.handle(_symbolMeta,
          symbol.isAcceptableOrUnknown(data['symbol']!, _symbolMeta));
    } else if (isInserting) {
      context.missing(_symbolMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('price')) {
      context.handle(
          _priceMeta, price.isAcceptableOrUnknown(data['price']!, _priceMeta));
    } else if (isInserting) {
      context.missing(_priceMeta);
    }
    if (data.containsKey('change_percent')) {
      context.handle(
          _changePercentMeta,
          changePercent.isAcceptableOrUnknown(
              data['change_percent']!, _changePercentMeta));
    } else if (isInserting) {
      context.missing(_changePercentMeta);
    }
    if (data.containsKey('last_updated')) {
      context.handle(
          _lastUpdatedMeta,
          lastUpdated.isAcceptableOrUnknown(
              data['last_updated']!, _lastUpdatedMeta));
    } else if (isInserting) {
      context.missing(_lastUpdatedMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {symbol};
  @override
  Crypto map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Crypto(
      symbol: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}symbol'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      price: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}price'])!,
      changePercent: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}change_percent'])!,
      lastUpdated: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}last_updated'])!,
    );
  }

  @override
  $CryptosTable createAlias(String alias) {
    return $CryptosTable(attachedDatabase, alias);
  }
}

class Crypto extends DataClass implements Insertable<Crypto> {
  final String symbol;
  final String name;
  final double price;
  final double changePercent;
  final int lastUpdated;
  const Crypto(
      {required this.symbol,
      required this.name,
      required this.price,
      required this.changePercent,
      required this.lastUpdated});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['symbol'] = Variable<String>(symbol);
    map['name'] = Variable<String>(name);
    map['price'] = Variable<double>(price);
    map['change_percent'] = Variable<double>(changePercent);
    map['last_updated'] = Variable<int>(lastUpdated);
    return map;
  }

  CryptosCompanion toCompanion(bool nullToAbsent) {
    return CryptosCompanion(
      symbol: Value(symbol),
      name: Value(name),
      price: Value(price),
      changePercent: Value(changePercent),
      lastUpdated: Value(lastUpdated),
    );
  }

  factory Crypto.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Crypto(
      symbol: serializer.fromJson<String>(json['symbol']),
      name: serializer.fromJson<String>(json['name']),
      price: serializer.fromJson<double>(json['price']),
      changePercent: serializer.fromJson<double>(json['changePercent']),
      lastUpdated: serializer.fromJson<int>(json['lastUpdated']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'symbol': serializer.toJson<String>(symbol),
      'name': serializer.toJson<String>(name),
      'price': serializer.toJson<double>(price),
      'changePercent': serializer.toJson<double>(changePercent),
      'lastUpdated': serializer.toJson<int>(lastUpdated),
    };
  }

  Crypto copyWith(
          {String? symbol,
          String? name,
          double? price,
          double? changePercent,
          int? lastUpdated}) =>
      Crypto(
        symbol: symbol ?? this.symbol,
        name: name ?? this.name,
        price: price ?? this.price,
        changePercent: changePercent ?? this.changePercent,
        lastUpdated: lastUpdated ?? this.lastUpdated,
      );
  Crypto copyWithCompanion(CryptosCompanion data) {
    return Crypto(
      symbol: data.symbol.present ? data.symbol.value : this.symbol,
      name: data.name.present ? data.name.value : this.name,
      price: data.price.present ? data.price.value : this.price,
      changePercent: data.changePercent.present
          ? data.changePercent.value
          : this.changePercent,
      lastUpdated:
          data.lastUpdated.present ? data.lastUpdated.value : this.lastUpdated,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Crypto(')
          ..write('symbol: $symbol, ')
          ..write('name: $name, ')
          ..write('price: $price, ')
          ..write('changePercent: $changePercent, ')
          ..write('lastUpdated: $lastUpdated')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(symbol, name, price, changePercent, lastUpdated);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Crypto &&
          other.symbol == this.symbol &&
          other.name == this.name &&
          other.price == this.price &&
          other.changePercent == this.changePercent &&
          other.lastUpdated == this.lastUpdated);
}

class CryptosCompanion extends UpdateCompanion<Crypto> {
  final Value<String> symbol;
  final Value<String> name;
  final Value<double> price;
  final Value<double> changePercent;
  final Value<int> lastUpdated;
  final Value<int> rowid;
  const CryptosCompanion({
    this.symbol = const Value.absent(),
    this.name = const Value.absent(),
    this.price = const Value.absent(),
    this.changePercent = const Value.absent(),
    this.lastUpdated = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  CryptosCompanion.insert({
    required String symbol,
    required String name,
    required double price,
    required double changePercent,
    required int lastUpdated,
    this.rowid = const Value.absent(),
  })  : symbol = Value(symbol),
        name = Value(name),
        price = Value(price),
        changePercent = Value(changePercent),
        lastUpdated = Value(lastUpdated);
  static Insertable<Crypto> custom({
    Expression<String>? symbol,
    Expression<String>? name,
    Expression<double>? price,
    Expression<double>? changePercent,
    Expression<int>? lastUpdated,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (symbol != null) 'symbol': symbol,
      if (name != null) 'name': name,
      if (price != null) 'price': price,
      if (changePercent != null) 'change_percent': changePercent,
      if (lastUpdated != null) 'last_updated': lastUpdated,
      if (rowid != null) 'rowid': rowid,
    });
  }

  CryptosCompanion copyWith(
      {Value<String>? symbol,
      Value<String>? name,
      Value<double>? price,
      Value<double>? changePercent,
      Value<int>? lastUpdated,
      Value<int>? rowid}) {
    return CryptosCompanion(
      symbol: symbol ?? this.symbol,
      name: name ?? this.name,
      price: price ?? this.price,
      changePercent: changePercent ?? this.changePercent,
      lastUpdated: lastUpdated ?? this.lastUpdated,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (symbol.present) {
      map['symbol'] = Variable<String>(symbol.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (price.present) {
      map['price'] = Variable<double>(price.value);
    }
    if (changePercent.present) {
      map['change_percent'] = Variable<double>(changePercent.value);
    }
    if (lastUpdated.present) {
      map['last_updated'] = Variable<int>(lastUpdated.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CryptosCompanion(')
          ..write('symbol: $symbol, ')
          ..write('name: $name, ')
          ..write('price: $price, ')
          ..write('changePercent: $changePercent, ')
          ..write('lastUpdated: $lastUpdated, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $CryptosTable cryptos = $CryptosTable(this);
  late final CryptoDao cryptoDao = CryptoDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [cryptos];
}

typedef $$CryptosTableCreateCompanionBuilder = CryptosCompanion Function({
  required String symbol,
  required String name,
  required double price,
  required double changePercent,
  required int lastUpdated,
  Value<int> rowid,
});
typedef $$CryptosTableUpdateCompanionBuilder = CryptosCompanion Function({
  Value<String> symbol,
  Value<String> name,
  Value<double> price,
  Value<double> changePercent,
  Value<int> lastUpdated,
  Value<int> rowid,
});

class $$CryptosTableFilterComposer
    extends Composer<_$AppDatabase, $CryptosTable> {
  $$CryptosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get symbol => $composableBuilder(
      column: $table.symbol, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get price => $composableBuilder(
      column: $table.price, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get changePercent => $composableBuilder(
      column: $table.changePercent, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get lastUpdated => $composableBuilder(
      column: $table.lastUpdated, builder: (column) => ColumnFilters(column));
}

class $$CryptosTableOrderingComposer
    extends Composer<_$AppDatabase, $CryptosTable> {
  $$CryptosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get symbol => $composableBuilder(
      column: $table.symbol, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get price => $composableBuilder(
      column: $table.price, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get changePercent => $composableBuilder(
      column: $table.changePercent,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get lastUpdated => $composableBuilder(
      column: $table.lastUpdated, builder: (column) => ColumnOrderings(column));
}

class $$CryptosTableAnnotationComposer
    extends Composer<_$AppDatabase, $CryptosTable> {
  $$CryptosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get symbol =>
      $composableBuilder(column: $table.symbol, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<double> get price =>
      $composableBuilder(column: $table.price, builder: (column) => column);

  GeneratedColumn<double> get changePercent => $composableBuilder(
      column: $table.changePercent, builder: (column) => column);

  GeneratedColumn<int> get lastUpdated => $composableBuilder(
      column: $table.lastUpdated, builder: (column) => column);
}

class $$CryptosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CryptosTable,
    Crypto,
    $$CryptosTableFilterComposer,
    $$CryptosTableOrderingComposer,
    $$CryptosTableAnnotationComposer,
    $$CryptosTableCreateCompanionBuilder,
    $$CryptosTableUpdateCompanionBuilder,
    (Crypto, BaseReferences<_$AppDatabase, $CryptosTable, Crypto>),
    Crypto,
    PrefetchHooks Function()> {
  $$CryptosTableTableManager(_$AppDatabase db, $CryptosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$CryptosTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$CryptosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$CryptosTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> symbol = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<double> price = const Value.absent(),
            Value<double> changePercent = const Value.absent(),
            Value<int> lastUpdated = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CryptosCompanion(
            symbol: symbol,
            name: name,
            price: price,
            changePercent: changePercent,
            lastUpdated: lastUpdated,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String symbol,
            required String name,
            required double price,
            required double changePercent,
            required int lastUpdated,
            Value<int> rowid = const Value.absent(),
          }) =>
              CryptosCompanion.insert(
            symbol: symbol,
            name: name,
            price: price,
            changePercent: changePercent,
            lastUpdated: lastUpdated,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$CryptosTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $CryptosTable,
    Crypto,
    $$CryptosTableFilterComposer,
    $$CryptosTableOrderingComposer,
    $$CryptosTableAnnotationComposer,
    $$CryptosTableCreateCompanionBuilder,
    $$CryptosTableUpdateCompanionBuilder,
    (Crypto, BaseReferences<_$AppDatabase, $CryptosTable, Crypto>),
    Crypto,
    PrefetchHooks Function()>;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$CryptosTableTableManager get cryptos =>
      $$CryptosTableTableManager(_db, _db.cryptos);
}
