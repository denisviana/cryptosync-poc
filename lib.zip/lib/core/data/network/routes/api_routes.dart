abstract class AuthRoutes {
  static const String signUp = '';
}
