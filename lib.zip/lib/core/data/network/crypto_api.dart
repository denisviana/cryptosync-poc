import 'dart:async';
import 'dart:convert';

import 'package:web_socket_channel/web_socket_channel.dart';

import '../../domain/entities/crypto_ticker.dart';

class CryptoApi {
  final WebSocketChannel _channel;
  StreamController<CryptoTicker>? _controller;

  CryptoApi(this._channel);

  /// Abre a stream de mini-tickers e retorna um Stream de [CryptoTicker].
  Stream<CryptoTicker> subscribeToTickers() {
    _controller ??= StreamController<CryptoTicker>.broadcast(
      onListen: _listenSocket,
      onCancel: () => _controller?.close(),
    );
    return _controller!.stream;
  }

  void _listenSocket() {
    _channel.stream.listen((raw) {
      try {
        final data = json.decode(raw);
        if (data is List) {
          for (final item in data) {
            final symbol = (item['s'] as String).replaceAll('USDT', '');
            final price = double.parse(item['c']);
            final change = double.parse(item['P']);
            _controller?.add(CryptoTicker(
              symbol: symbol,
              price: price,
              percentChange: change,
              name: symbol,
              lastUpdated: DateTime.now(),
            ));
          }
        }
      } on Exception catch (_) {}
    });
  }

}
