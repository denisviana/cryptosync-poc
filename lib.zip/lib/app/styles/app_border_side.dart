import 'package:flutter/cupertino.dart';
import 'app_theme.dart';

class AppBorderSide {
  static BorderSide regular = BorderSide(color: AppColorScheme.border, width: 1);
}
